package com.example.smarthome3.Views;

public  enum AccountType {
    HOMEOWNER,
    TECHNICIAN,
    SECURITYGUARD
}
